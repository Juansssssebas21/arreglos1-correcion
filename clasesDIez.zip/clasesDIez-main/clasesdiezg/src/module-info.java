module clasesdiezg {
}