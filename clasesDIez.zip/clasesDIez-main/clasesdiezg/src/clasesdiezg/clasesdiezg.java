package clasesdiezg;

public class clasesdiezg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
