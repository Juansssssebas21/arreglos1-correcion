package balantaarreglos1;

public class balanta {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
